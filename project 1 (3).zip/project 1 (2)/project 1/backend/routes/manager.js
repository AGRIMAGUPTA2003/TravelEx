const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Expense = require('../models/Expense');
const TravelRequest = require('../models/TravelRequest');
const User = require('../models/User');
const io = require('../server');

// Middleware to ensure manager role (assumes req.user is set by auth middleware)
function requireManager(req, res, next) {
  if (!req.user || req.user.role.toLowerCase() !== 'manager') {
    return res.status(403).json({ success: false, message: 'Access denied: Managers only' });
  }
  next();
}

// GET /api/manager/summary
router.get('/summary', requireManager, async (req, res) => {
  try {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfQuarter = new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1);
    const startOfYear = new Date(now.getFullYear(), 0, 1);

    const [monthTotal, quarterTotal, yearTotal, pendingCount, policyViolations, reimbursed, pending] = await Promise.all([
      Expense.aggregate([
        { $match: { date: { $gte: startOfMonth } } },
        { $group: { _id: null, total: { $sum: '$amount' } } }
      ]),
      Expense.aggregate([
        { $match: { date: { $gte: startOfQuarter } } },
        { $group: { _id: null, total: { $sum: '$amount' } } }
      ]),
      Expense.aggregate([
        { $match: { date: { $gte: startOfYear } } },
        { $group: { _id: null, total: { $sum: '$amount' } } }
      ]),
      Expense.countDocuments({ status: 'Pending' }),
      Expense.countDocuments({ policyViolation: true }),
      Expense.aggregate([
        { $match: { status: 'Reimbursed' } },
        { $group: { _id: null, total: { $sum: '$amount' } } }
      ]),
      Expense.aggregate([
        { $match: { status: 'Pending' } },
        { $group: { _id: null, total: { $sum: '$amount' } } }
      ])
    ]);

    res.json({
      success: true,
      data: {
        totalExpensesMonth: monthTotal[0]?.total || 0,
        totalExpensesQuarter: quarterTotal[0]?.total || 0,
        totalExpensesYear: yearTotal[0]?.total || 0,
        pendingApprovals: pendingCount,
        policyViolations,
        reimbursed: reimbursed[0]?.total || 0,
        pendingAmount: pending[0]?.total || 0
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
});

// GET /api/manager/pending-approvals
router.get('/pending-approvals', requireManager, async (req, res) => {
  try {
    const approvals = await Expense.find({ status: 'Pending' })
      .populate('employee', 'name email')
      .sort({ date: -1 });
    const travelRequests = await TravelRequest.find({ status: 'Pending' })
      .populate('employee', 'name email')
      .sort({ start: -1 });
    res.json({ success: true, data: { expenses: approvals, travelRequests } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
});

// GET /api/manager/employee-overview
router.get('/employee-overview', requireManager, async (req, res) => {
  try {
    // Top spenders (by total expense)
    const topSpenders = await Expense.aggregate([
      { $group: { _id: '$employee', total: { $sum: '$amount' } } },
      { $sort: { total: -1 } },
      { $limit: 5 }
    ]);
    // Frequent travelers (by count of travel requests)
    const frequentTravelers = await TravelRequest.aggregate([
      { $group: { _id: '$employee', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 5 }
    ]);
    // Expense trends (monthly totals for current year)
    const now = new Date();
    const startOfYear = new Date(now.getFullYear(), 0, 1);
    const trends = await Expense.aggregate([
      { $match: { date: { $gte: startOfYear } } },
      { $group: { _id: { month: { $month: '$date' } }, total: { $sum: '$amount' } } },
      { $sort: { '_id.month': 1 } }
    ]);
    // Populate user names
    const userIds = [...new Set([...topSpenders.map(s => s._id), ...frequentTravelers.map(f => f._id)])];
    const users = await User.find({ _id: { $in: userIds } }).select('name email');
    const userMap = Object.fromEntries(users.map(u => [u._id.toString(), u]));
    res.json({
      success: true,
      data: {
        topSpenders: topSpenders.map(s => ({ ...s, employee: userMap[s._id?.toString()] })),
        frequentTravelers: frequentTravelers.map(f => ({ ...f, employee: userMap[f._id?.toString()] })),
        expenseTrends: trends
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
});

// POST /api/manager/approve-travel/:id
router.post('/approve-travel/:id', requireManager, async (req, res) => {
  try {
    const travelRequest = await TravelRequest.findByIdAndUpdate(
      req.params.id,
      { status: 'Approved' },
      { new: true }
    );
    if (!travelRequest) return res.status(404).json({ success: false, message: 'Travel request not found' });
    res.json({ success: true, data: travelRequest });
    io.emit('dashboardUpdate');
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
});

// POST /api/manager/reject-travel/:id
router.post('/reject-travel/:id', requireManager, async (req, res) => {
  try {
    const travelRequest = await TravelRequest.findByIdAndUpdate(
      req.params.id,
      { status: 'Rejected' },
      { new: true }
    );
    if (!travelRequest) return res.status(404).json({ success: false, message: 'Travel request not found' });
    res.json({ success: true, data: travelRequest });
    io.emit('dashboardUpdate');
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
});

// POST /api/manager/approve-expense/:id
router.post('/approve-expense/:id', requireManager, async (req, res) => {
  try {
    const expense = await Expense.findByIdAndUpdate(
      req.params.id,
      { status: 'Reimbursed' },
      { new: true }
    );
    if (!expense) return res.status(404).json({ success: false, message: 'Expense not found' });
    res.json({ success: true, data: expense });
    io.emit('dashboardUpdate');
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
});

// POST /api/manager/reject-expense/:id
router.post('/reject-expense/:id', requireManager, async (req, res) => {
  try {
    const expense = await Expense.findByIdAndUpdate(
      req.params.id,
      { status: 'Rejected' },
      { new: true }
    );
    if (!expense) return res.status(404).json({ success: false, message: 'Expense not found' });
    res.json({ success: true, data: expense });
    io.emit('dashboardUpdate');
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
});

module.exports = router;
